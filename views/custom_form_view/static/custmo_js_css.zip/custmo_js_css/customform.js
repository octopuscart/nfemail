
function setAnimation(obj, x) {
    $(obj).removeClass(x).addClass(x).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
        $(this).removeClass(x);

    });
}


//function for set summery information accroding to selected styles and fabric selection 
function setSummery() {
    checkShritValidation();
    var htmls = "<table class='table'><tr><th colspan=2></th><th colspan=2 class='heading_price' style='text-align:left'>Extra Price</th></tr>";
    var gran_total = 0;
    for (i in productStyleArray) {
        //start of first loop
        var temp = productStyleArray[i];
        htmls += "<tr><th class='headingthm' colspan=4>" + cartIdMap[i] + "</th></tr>";
        var total = 0;
        for (j in temp) {
            // start of inner loop
            
            var temp2 = temp[j];
            if (temp2 == "") {
                //setting of error box which selections are missed
                htmls += "<tr class='errortd'><th class='headingth errortd' parent='" + i + "' removedata='" + j + "' >" + j + "</th><td class='headingth errortd'>" + temp2 + "</td>"
                htmls += "<td class='heading_price'></td>";
                htmls += "<td><i class='fa fa-edit removethis' parent='" + i + "' removedata='" + j + "'></td></tr>";
            }
            else {
                
                //calculation of extra price
                var extra_price = productStyleArrayPrice[i][j];
                if(extra_price){
                    total += Number(extra_price);
                    extra_price = "$"+extra_price;
                }
                else{
                    extra_price = "";
                }
                
                //setting of extra price
                htmls += "<tr ><th class='headingth'>" + j + "</th><td class='headingtd'>" + temp2 + "</td>";
                htmls += "<td class='heading_price'>"+extra_price+"</td>";
                
                //setting of remove buttion
                htmls += "<td><i class='fa fa-edit removethis' parent='" + i + "' removedata='" + j + "'></td></tr>";
                
            }
            
            //setting of sort summery
            
            $("th[parent='"+i+"'][styleselect='"+j+"']").text(temp2);
            
            var crtCheck = $("[target_product='" + i + "']");
            var titleDiv = $(crtCheck).parents(".col-md-12").find("dd li .mes_title:contains('" + j + "')");
            $(titleDiv).siblings().first().text(temp2);
        //end of sort summery
          
          
        } //end of inner loop
        
        //setting of total price of each fabric
        gran_total += total;
        htmls += "<tr><th class='total_price' colspan=3>$" + total + "</th><th></th></tr>";
    //end of total price
    
    }//end of outer loop
    
    //setting of grand total price
    htmls += "<tr class='grand_total'><th class='' colspan=2>Total Extra Price</th><th class=''>$" + gran_total + "</th><th></th></tr>";
    
    htmls += "<tr><th class='headingthm' colspan=4>Your Space</th></tr>";
    htmls += "<tr><th class='final_summary' colspan=4 ></th></tr>";
    
    htmls += "</table>";
    
    //setting of all summery page
    $(".measurment_summery").html(htmls);
    
    return htmls;
}
//end of set summery function 



function CustomForm() {
    this.Init = function (setpos) {
        setSummery();
        
        $(".fabrics").animate({
            'display': 'block'
        }, 100, function () {
            var obj = this;
            var x = 'bounceInRight';
            $(obj).removeClass(x).addClass(x).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
                $(this).removeClass(x);
            });
        });
       
       
        $(".thumbnail").animate({
            'display': 'block'
        }, 100 , function () {
            var obj = this;
            var x = 'flipInX';
            $(obj).removeClass(x).addClass(x).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
                $(this).removeClass(x);
           
            });
        })      
    }
}


var bodyObj = new CustomForm();
bodyObj.Init(1);


var crtSelection = "";
var crtTitle = "";
var crtPrice = "";

$("document").ready(function () {
    
    //    $("#containerBox").draggable(); 


    $('.custmo_form_setup  a[data-toggle="tab"]').on('click', function (e) {
        $(".final_summary").html($("#your_space_text").code());
        var crtTab = $(e.target).attr("aria-controls");
    });



    $(".nextStyle").click(function () {
        var nextTab = $($(".custmo_form_setup .vertialTab li.active")).next().find("a").tab("show");
        $("body").animate({
            "scrollTop": 100
        }, function () {
            $("#containerBox").animate({
                "top": $("#body_fit").position().top
            });
        })
    });


    $(".previousStyle").click(function () {
        $($(".custmo_form_setup .vertialTab li.active")).prev().find("a").tab("show");
        $("body").animate({
            "scrollTop": 100
        }, function () {
            $("#containerBox").animate({
                "top": $("#front").position().top
            });
        })
    });



    $(".btn-group button").click(function () {
        $(this).removeClass("active").addClass("active");
        $(this).siblings().removeClass("active");
    })



    $(".style_selection").bind("click keyup", function () {
        

        
        var itsTitle = $(this).attr("parent_style");
        var selected_title = itsTitle;
        
        var selected_value = $(this).attr("child_style");
        var selected_price = $(this).attr("extra_price");
        
          
        
        if($(this).find("select").length){
            var selected_value = $(this).find("select").val();
            selected_value = selected_value; 
        }
        
        if($(this).hasClass("form-control")){
            var selected_value = $(this).val();
            selected_value = selected_value; 
        }   
        
        $("#style_heading").text(selected_title);
        $(".check_icon").each(function (index) {
            if (selected_title != crtTitle) {
                var checkData = $(this).parents(".col-md-12").find(".selectedTitle").text("");
                var productCheck = $(this).attr("target_product");
                var selectedPreValue = $("th[parent='"+productCheck+"'][styleselect='"+selected_title+"']").text();
                //                var titleDiv = $(this).parents(".col-md-12").find("dd li .mes_title:contains('" + selected_title + "')");
                //                var selectedPreValue = $(titleDiv).siblings().first().text();
                var checkData = $(this).parents(".col-md-12").find(".selectedTitle").text(selectedPreValue);
            }
            this.checked = false;

        });



        crtSelection = selected_value;
        crtTitle = selected_title;
        crtPrice = selected_price;


        var divpos = $(this).offset();

        $("#containerBox").animate({
            "top": divpos.top - 228
        });

        if ($(this).hasClass("selected")) {
        }
        else {

            $(this).addClass("selected").removeClass("deselect");
            var x = 'flipInY';
            $(this).removeClass(x).addClass(x).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
                $(this).removeClass(x);
                
            });

            $(this).parents("div").first().siblings().each(function () {
              
                $(this).find(".thumbnail").removeClass("selected").addClass("deselect");
            });
            
            $(this).parents(".owl-item").first().siblings().each(function () {
               
                $(this).find(".thumbnail").removeClass("selected").addClass("deselect");
            });
        }
    });







    function setMeasurment(obj) {
        if (crtTitle != "") {
            var productCheck = $(obj).attr("target_product");
            productStyleArray[productCheck][crtTitle] = crtSelection;
            productStyleArrayPrice[productCheck][crtTitle] = crtPrice;
            
            
            // shirt custom validation 
            if(custom_form == 'nfw_shirt_custom'){
                checkMonogramOther(crtTitle, productCheck);
                checkMonogramPlacementValidation(productCheck);
                noMonogramValidation(productCheck);
            }
            //end of shirt custom validation
            
            
            // shirt custom validation 
            if(custom_form == 'tuxedoshirtcustom'){
                checkMonogramOther(crtTitle, productCheck);
                checkMonogramPlacementValidation(productCheck);
                noMonogramValidation(productCheck);
                frontFlyStudButtons(productCheck);
            }
            //end of shirt custom validation
            
            
            if (obj.checked) {
                $(obj).parents(".col-md-12").find(".selectedTitle").text(crtSelection);
            }
            else {
                $(obj).parents(".col-md-12").find(".selectedTitle").text("");
            }
        }
        else {
            obj.checked = false;
            $(".check_icon_all")[0].checked = false;
            alert("Please Select Style!")
        }
        setSummery()
    }





    $(".product_check").click(function () {
        setMeasurment(this);
        if ($(this).is(':checked')) {
        }
        else {
            $(".check_icon_all")[0].checked = false;
        }
    });
    

    $(".check_icon_all").click(function () {
        if ($(this).is(':checked')) {
            $(".check_icon").each(function (index) {
                if (index) {
                    this.checked = true;
                    setMeasurment(this);
                }
            })
        }
        else {
            $(".check_icon").each(function (index) {
                if (index) {
                    this.checked = false;
                    setMeasurment(this);
                }
            })
        }

    });


    $(".checkAllStyle").click(function () {
        if ($(this).hasClass("btn-success")) {
            $(".check_icon").each(function (index) {
                if (index) {
                    this.checked = false;

                }
            })
        }
    });

    $(".removefabric").click(function () {
        var productCheck = $(this).attr("target_product");
        $(this).parents(".col-md-12").remove();
        delete productStyleArray[productCheck]
    });

    $(document).on("click", ".errortd", function () {
        var parentdiv = $(this).attr("parent");
        var tabitem = $(this).text();

        var divobj = $("div.panel-heading:contains('" + tabitem + "'), div.sub_heading:contains('" + tabitem + "')").parents("[role=tabpanel]").first();
        var tabid = divobj[0].id;
        var targetTab = $("a[href='#" + tabid + "']");
        var parentPos = $("div.panel-heading:contains('" + tabitem + "'), div.sub_heading:contains('" + tabitem + "')").parents(".panel");
        var divpos = $(parentPos).offset();
        $("#containerBox").animate({
            "top": (divpos.top) - 220
        }, function () {
            var body = $("html, body");
            body.stop().animate({
                'scrollTop': $("#containerBox").offset().top - 228
            }, 500, 'swing');
        });
        $(targetTab).tab("show");

    });



    $(document).on("click", ".removethis", function () {
        var parentele = $(this).attr("parent");
        var parentremovetag = $(this).attr("removedata");
        productStyleArray[parentele][parentremovetag] = "";
        setSummery();
        var crtCheck = $("[target_product='" + parentele + "']");   
        var selectedHeading = $(".style_heading").text();
    
        if (selectedHeading == parentremovetag){
            crtCheck[0].checked = false;
            $(crtCheck).parents(".col-md-12").find(".selectedTitle").text("");
        }
        $("#containerBox").show(300);
    });
})



$(document).on("change", ".extra_buttons", function () {
    var imgCode = $(this).val();
    imgCode = imgCode.split(" ")[1];
    $(this).parents(".thumbnail").find("img").attr("src", "./custom_form_view/suit/suitbuttongsbl/"+imgCode+".JPG");
         
});
    
    
